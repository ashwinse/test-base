#!/bin/bash

AZ_VAR_scope="/subscriptions/$AZ_VAR_subscription_id/resourcegroups/$AZ_VAR_resource_group"
cat permissions.json | jq --arg scope "$AZ_VAR_scope" --arg auuid "$AZ_VAR_deployment_auuid" '.AssignableScopes[0] |= $scope | .Id = $auuid | .Name = $auuid' > permissions_updated.json