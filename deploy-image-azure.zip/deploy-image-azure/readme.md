# Oracle Bare Metal Cloud - Docker Image
