#!/bin/bash
az resource list -g "$AZ_VAR_resource_group"