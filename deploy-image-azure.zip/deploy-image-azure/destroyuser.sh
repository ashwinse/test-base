
#!/bin/bash

az ad user delete --upn $AZ_VAR_user_email