#!/bin/bash

az group deployment validate \
--resource-group "$AZ_VAR_resource_group" \
--template-file azuredeploy.json \
--parameters azuredeploy.parameters.json