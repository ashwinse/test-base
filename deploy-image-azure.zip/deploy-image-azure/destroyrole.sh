#!/bin/bash
az role definition delete --name 