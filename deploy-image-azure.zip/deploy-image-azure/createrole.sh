#!/bin/bash
role_resp = `az role definition create --role-definition permissions_updated.json`
AZ_VAR_role_definition_id="`$role_resp | jq '.id'`"
AZ_VAR_role_definition_name="`$role_resp | jq '.name'`"

#modify the permission for following propertie  id, name, assigable scope
#AZ_VAR_role_definition_id=role_res.id
#AZ_VAR_role_definition_name=role_res.name