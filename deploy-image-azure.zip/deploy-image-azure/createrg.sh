#!/bin/bash
az group create --name "$AZ_VAR_resource_group" --location "$AZ_VAR_location"
