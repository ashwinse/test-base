
#!/bin/bash
user_resp=`az ad user create --display-name $AZ_VAR_username --password $AZ_VAR_password --user-principal-name $AZ_VAR_user_email --force-change-password-next-login false | jq '.objectId'`
AZ_VAR_user_principal_id="$user_resp"

