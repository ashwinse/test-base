#!/bin/bash

az group delete --name $AZ_VAR_resource_group -y
