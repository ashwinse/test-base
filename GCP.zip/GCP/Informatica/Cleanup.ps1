Write-Host "Hello world"
java -jar .\AWSCreateUser.jar CLEANUP -classpath $Env:CLASSPATH
